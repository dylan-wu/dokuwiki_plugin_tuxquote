The supplied images were sourced from ChrystalXP.net (http://www.crystalxp.net/) and are all distributed under the Creative Commons BY-NC-SA license (http://creativecommons.org/licenses/by-nc-sa/3.0/)

Under the Creative Commons BY-NC-SA license, with the images supplied in this this plugin (Tuxquote), you are free to:

Share - copy and redistribute the material in any medium or format
Adapt - remix, transform, and build upon the material
The licensor cannot revoke these freedoms as long as you follow the license terms.

Under the following terms:

Attribution - You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
NonCommercial - You may not use the material for commercial purposes.
ShareAlike - If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.
No additional restrictions - You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

Notices:

You do not have to comply with the license for elements of the material in the public domain or where your use is permitted by an applicable exception or limitation.
No warranties are given. The license may not give you all of the permissions necessary for your intended use. For example, other rights such as publicity, privacy, or moral rights may limit how you use the material.

The following ChrystalXP.net members are attributed with the supplied images:

abney317 (http://www.crystalxp.net/forum/en/profil-121515.htm)
santung (http://www.crystalxp.net/forum/en/profil-27983.htm)
adrielhernandez (http://tux.crystalxp.net/en.user.285179.1.12.html)
brunocb (http://igloo.crystalxp.net/Brunocb)
SMN (http://tux.crystalxp.net/en.user.190553.1.12.html)
Debsy (http://tux.crystalxp.net/en.user.24307.1.12.html)
mimipunk (http://tux.crystalxp.net/en.user.2109.1.12.html)
kami23 (http://tux.crystalxp.net/en.user.21587.1.12.html)
umrfix (http://tux.crystalxp.net/en.user.356936.1.12.html)
pusio (http://tux.crystalxp.net/en.user.330619.1.12.html)
fcys14 (http://tux.crystalxp.net/en.user.386.1.12.html)
clementes (http://tux.crystalxp.net/en.user.353072.1.12.html)
juanito15 (http://tux.crystalxp.net/en.user.380646.1.12.html)
xeoon (http://www.crystalxp.net/forum/en/profil-95808.htm)
mimipunk (http://tux.crystalxp.net/en.user.2109.1.12.html)
BB42 (http://tux.crystalxp.net/en.user.77497.1.12.html)
chaco (http://tux.crystalxp.net/en.user.9168.1.12.html)
alexandrafranco (http://tux.crystalxp.net/en.user.78748.1.12.html)
ZafX (http://tux.crystalxp.net/en.user.342192.1.12.html)
masta64 (http://tux.crystalxp.net/en.user.134806.1.12.html)
pinguinalulu (http://tux.crystalxp.net/en.user.164668.1.12.html)
BuD0KaI (http://tux.crystalxp.net/en.user.132435.1.12.html)
silver4 (http://tux.crystalxp.net/en.user.609.1.12.html)
madgad (http://tux.crystalxp.net/en.user.17562.1.12.html)
RyannRocks7498 (http://tux.crystalxp.net/en.user.299475.1.12.html)
pit-tux (http://tux.crystalxp.net/en.user.1757.1.12.html)
porkytux (http://tux.crystalxp.net/en.user.354912.1.12.html)
Ominamu (http://tux.crystalxp.net/en.user.5202.1.12.html)
podoxav (http://tux.crystalxp.net/en.user.2240.1.12.html)
adrielhernandez (http://tux.crystalxp.net/en.user.285179.1.12.html)
Nidoki (http://tux.crystalxp.net/en.user.3642.1.12.html)
Overlord59 (http://tux.crystalxp.net/en.user.194.1.12.html)
Neoshin (http://tux.crystalxp.net/en.user.3137.1.12.html)
batux (http://tux.crystalxp.net/en.user.110.1.12.html)
CRESTON (http://tux.crystalxp.net/en.user.299233.1.12.html)
Wyvern (http://www.crystalxp.net/forum/en/profil-21410.htm)
osh_c (http://www.crystalxp.net/forum/en/profil-131332.htm)
logics  (http://www.crystalxp.net/forum/en/profil-145124.htm)
cisoun (http://tux.crystalxp.net/en.user.43159.1.12.html)
chozo-mj (http://tux.crystalxp.net/en.user.2537.1.12.html)
fcys14 (http://tux.crystalxp.net/en.user.386.1.12.html)
ortizvlasich (http://tux.crystalxp.net/en.user.49382.1.12.html)
tohig (http://tux.crystalxp.net/en.user.174903.1.12.html)
Bluezoeme (http://tux.crystalxp.net/en.user.758.1.12.html)
Barbecue (http://igloo.crystalxp.net/Barbecue)
Laurwin (http://tux.crystalxp.net/en.user.14306.1.12.html)
manuoceane (http://tux.crystalxp.net/en.user.98057.1.12.html)
Novadk (http://www.crystalxp.net/forum/en/profil-25516.htm)
Dobaz604 (http://www.crystalxp.net/forum/en/profil-27289.htm)
Seyv (http://www.crystalxp.net/forum/en/profil-100330.htm)

